from Houdini.HoudiniFactory import HoudiniFactory

server = HoudiniFactory(server="Icecube")
server.start()