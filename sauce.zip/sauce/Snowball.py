from Houdini.HoudiniFactory import HoudiniFactory

server = HoudiniFactory(server="Snowball")
server.start()