# -*- coding: utf-8 -*-
import time
from beaker.cache import region_invalidate as Invalidate
from discord_webhook import DiscordWebhook, DiscordEmbed
from Houdini.Spheniscidae import Spheniscidae
from Houdini.Data.Penguin import Inventory, IglooInventory, FurnitureInventory, LocationInventory
from Houdini.Data.Puffle import Puffle, CareInventory
from Houdini.Data.Postcard import Postcard
from Houdini.Data.Stamp import Stamp
from Houdini.Data.Deck import Deck
from Houdini.Data import retryableTransaction
from Houdini.Data.Penguin import ServerStats

from Houdini.Handlers.Games.Table import leaveTable
from Houdini.Handlers.Games.Waddle import leaveWaddle
from Houdini.Handlers.Play.Stampbook import getStampsString


class Penguin(Spheniscidae):

    def __init__(self, session, spirit):
        super(Penguin, self).__init__(session, spirit)
        self.user = None
        self.throttle = {}

        self.frame = 1
        self.x, self.y = (0, 0)
        self.age = 0
        self.muted = False
        self.playerString = None

        self.table = None
        self.waddle = None
        self.gameFinished = True

        self.walkingPuffle = None
        self.digCount = 0
        self.canDigGold = False

        self.logger.info("Penguin class instantiated")

    def addCareItem(self, careItemId, additionalQuantity=1, itemCost=0, sendXt=True):
        if careItemId in self.careInventory:
            itemQuantity = self.careInventory[careItemId]
            itemQuantity += additionalQuantity

            # TODO: Remove this limit?
            if itemQuantity >= 100:
                return False

            self.session.query(CareInventory).filter_by(PenguinID=self.user.ID, ItemID=careItemId) \
                .update({"Quantity": itemQuantity})
        else:
            itemQuantity = additionalQuantity
            self.session.add(CareInventory(PenguinID=self.user.ID, ItemID=careItemId, Quantity=additionalQuantity))

        self.careInventory[careItemId] = itemQuantity
        self.user.Coins -= itemCost

        if sendXt:
            self.sendXt("papi", self.user.Coins, careItemId, itemQuantity)

    def addItem(self, itemId, itemCost=0, sendXt=True):
        if itemId in self.inventory:
            return False

        self.inventory.append(itemId)
        self.session.add(Inventory(PenguinID=self.user.ID, ItemID=itemId))

        self.user.Coins -= itemCost

        if sendXt:
            self.sendXt("ai", itemId, self.user.Coins)

    def addIgloo(self, iglooId, iglooCost=0):
        if iglooId in self.iglooInventory:
            return False

        self.iglooInventory.append(iglooId)
        self.session.add(IglooInventory(PenguinID=self.user.ID, IglooID=iglooId))
        self.user.Coins -= iglooCost

        self.sendXt("au", iglooId, self.user.Coins)

    def addLocation(self, locationId, locationCost=0):
        if locationId in self.locations:
            return False

        self.iglooInventory.append(locationId)
        self.session.add(LocationInventory(PenguinID=self.user.ID, LocationID=locationId))
        self.user.Coins -= locationCost

        self.sendXt("aloc", locationId, self.user.Coins)

    def addFurniture(self, furnitureId, furnitureCost=0, sendXt=True):
        furnitureQuantity = 1

        if furnitureId in self.furniture:
            furnitureQuantity = self.furniture[furnitureId]
            furnitureQuantity += 1

            if furnitureQuantity >= 100:
                return False

            self.session.query(FurnitureInventory).filter_by(PenguinID=self.user.ID, FurnitureID=furnitureId) \
                .update({"Quantity": furnitureQuantity})
        else:
            self.session.add(FurnitureInventory(PenguinID=self.user.ID, FurnitureID=furnitureId))

        self.furniture[furnitureId] = furnitureQuantity
        self.user.Coins -= furnitureCost

        if sendXt:
            self.sendXt("af", furnitureId, self.user.Coins)

    def addFlooring(self, floorId, floorCost=0):
        self.user.Coins -= floorCost
        self.igloo.Floor = floorId

        self.sendXt("ag", floorId, self.user.Coins)

    def addStamp(self, stampId, sendXt=False):
        if stampId in self.stamps:
            return False

        self.stamps.append(stampId)
        self.recentStamps.append(stampId)
        self.session.add(Stamp(PenguinID=self.user.ID, Stamp=stampId))

        if sendXt:
            self.sendXt("aabs", stampId)
        Invalidate(getStampsString, 'houdini', 'stamps', self.user.ID)

    def addCards(self, *args):
        for cardId in args:
            cardQuantity = 1

            if cardId in self.deck:
                cardQuantity = self.deck[cardId]
                cardQuantity += 1

                self.session.query(Deck).filter_by(PenguinID=self.user.ID, CardID=cardId) \
                    .update({"Quantity": cardQuantity})
            else:
                self.session.add(Deck(PenguinID=self.user.ID, CardID=cardId))

            self.deck[cardId] = cardQuantity
            self.cards.append(self.server.cards[cardId])

    def ninjaRankUp(self, levels=1):
        rankAwards = [4025, 4026, 4027, 4028, 4029, 4030, 4031, 4032, 4033, 104]
        beltPostcards = {1: 177, 5: 178, 9: 179}
        beltStamps = {1: 230, 5: 232, 9: 234, 10: 236}
        for i in xrange(levels):
            if self.user.NinjaRank == 10:
                return False
            self.user.NinjaRank += 1
            self.user.NinjaProgress = 0
            self.addItem(rankAwards[self.user.NinjaRank - 1], sendXt=False)
            if self.user.NinjaRank in beltPostcards:
                self.receiveSystemPostcard(beltPostcards[self.user.NinjaRank])
            if self.user.NinjaRank in beltStamps:
                self.addStamp(beltStamps[self.user.NinjaRank], True)

    def joinRoom(self, roomId):
        self.room.remove(self)
        self.server.rooms[roomId].add(self)

    @retryableTransaction()
    def receiveSystemPostcard(self, postcardId, details=""):
        postcard = Postcard(RecipientID=self.user.ID, SenderID=None, Details=details, Type=postcardId)
        self.session.add(postcard)
        self.session.commit()
        self.sendXt("mr", "sys", 0, postcardId, details, int(time.time()), postcard.ID)

    def sendCoins(self, coinAmount):
        self.user.Coins = coinAmount
        self.sendXt("zo", self.user.Coins, "", 0, 0, 0)

    def getPlayerString(self):
        if self.walkingPuffle is not None:
            print(self.user.namecolor)
            playerArray = [
                self.user.ID, # 0 
                self.user.Nickname, # 1
                self.user.Approval, # 2
                self.user.Color, # 3
                self.user.Head, # 4
                self.user.Face, # 5
                self.user.Neck, # 6
                self.user.Body, # 7 
                self.user.Hand, # 8 
                self.user.Feet,# 9 
                self.user.Flag, #10
                self.user.Photo, # 11
                self.x, self.y,# 12, 13
                self.frame,# 14
                1, self.age,# 15, 16
                0, # Avatar integer, not entirely sure how this works yet 17
                str(), # Unused value 18
                str(), # Party information 19
                self.walkingPuffle.ID, # 20 
                self.walkingPuffle.Type, # 21
                self.walkingPuffle.Subtype if self.walkingPuffle.Subtype else str(), # 22
                self.walkingPuffle.Hat,  # 23
                0, # 24
                self.user.namecolor # 25
                ]
            playerStringArray = map(str, playerArray)
            self.playerString = "|".join(playerStringArray)

            return self.playerString
        else:
            playerArray = [
                self.user.ID, # 0 
                self.user.Nickname, # 1
                self.user.Approval, # 2
                self.user.Color, # 3
                self.user.Head, # 4
                self.user.Face, # 5
                self.user.Neck, # 6
                self.user.Body, # 7 
                self.user.Hand, # 8 
                self.user.Feet,# 9 
                self.user.Flag, #10
                self.user.Photo, # 11
                self.x, self.y,# 12, 13
                self.frame,# 14
                1, self.age,# 15, 16
                0, # Avatar integer, not entirely sure how this works yet 17
                str(), # Unused value 18
                str(), # Party information 19
                str(), # 20 
                str(), # 21
                str(), # 22
                str(),  # 23
                str(), # 24
                self.user.namecolor, # 25
                ]
            playerStringArray = map(str, playerArray)
            self.playerString = "|".join(playerStringArray)

            return self.playerString

    def connectionLost(self, reason):
        if hasattr(self, "room") and self.room is not None:
            self.room.remove(self)

            for buddyId in self.buddies.keys():
                if buddyId in self.server.players:
                    self.server.players[buddyId].sendXt("bof", self.user.ID)

            loginUnix = time.mktime(self.login.Date.timetuple())
            minutesPlayed = int(time.time() - loginUnix) / 60
            self.user.MinutesPlayed += minutesPlayed
            self.session.add(self.login)
            webhook = DiscordWebhook(url='https://discordapp.com/api/webhooks/655894779720105986/GyOLdV9Z4VG03n5U_YnR2-s-aLL1nK2H7SN3kmBtg-ID4C7Usm58a1pvLEg7WVLrhiJX')
            embed = DiscordEmbed(title='Disconnection Activity', description='**{} has disconnected from the server {}**'.format(self.user.Username, self.server.serverName), color=0x240b3b)
            embed.set_footer(text='powered by rsakeys.org 🚀')
            webhook.add_embed(embed)
            response = webhook.execute()
            serverStats = self.session.query(ServerStats).filter(ServerStats.ID == 340).first()
            if serverStats.Count == 0:
                return
            else:
                newCount = serverStats.Count-1
                print('Goodbye player! New count: %s' % newCount)
                self.session.query(ServerStats).filter_by(ID=340) \
                                .update({"Count": newCount})
                print('Updating stats...')
                

            self.server.redis.srem("%s.players" % self.server.serverName, self.user.ID)
            self.server.redis.decr("%s.population" % self.server.serverName)

        super(Penguin, self).connectionLost(reason)
        # After the data has been committed; to ensure that the data was saved.
        map(self.session.expunge, self.igloos.values())
        map(self.session.expunge, self.puffles.values())