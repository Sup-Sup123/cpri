import logging
logging.basicConfig(level=logging.DEBUG)

logging.getLogger("beaker.container").setLevel(logging.INFO)