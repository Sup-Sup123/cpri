import zope.interface, logging, os, re
from Houdini.Plugins import Plugin
from Houdini.Handlers import Handlers

from Houdini.Handlers.Play.Message import handleSendMessage
from Houdini.Handlers.Play.Pet import handleSendAdoptPuffle
from Houdini.Handlers.Play.Moderation import moderatorKick

from collections import Counter, OrderedDict

class OrderedCounter(Counter, OrderedDict):
    pass

class SwearFilter(object):
    zope.interface.implements(Plugin)

    author = "Houdini Team"
    version = 0.1
    description = "Block naughty words from being sent in game"
    def __init__(self, server):
        self.logger = logging.getLogger("Houdini")

        self.server = server

        configFile = os.path.dirname(os.path.realpath(__file__)) + "/words"
        with open(configFile, "r") as fileHandle:
            self.words = fileHandle.read().split("\n")

        if self.server.server["World"]:
            Handlers.Message -= handleSendMessage
            Handlers.Message += self.handleSendMessage

            Handlers.AdoptPuffle -= handleSendAdoptPuffle
            Handlers.AdoptPuffle += self.handleSendAdoptPuffle

    @staticmethod
    def makeRegexBadWord(badWord):
        return "".join([char if count == 1 else char + "{" + str(count) + ",}"
                        for char, count in OrderedCounter(badWord).iteritems()])

    @staticmethod
    def removeSpecialChars(message):
        return "".join(e for e in message if e.isalnum())

    def isNaughty(self, string):
        cleanMessage = string.lower()
        cleanMessage = cleanMessage.split(' ')
        for word in self.words:
            r = re.compile(".*{}".format(word))
            newlist = list(filter(r.match, cleanMessage))  
            if word in newlist:
                if word == '':
                    return False
                else:
                    return True

    def handleSendMessage(self, player, data):
        if self.isNaughty(data.Message):
            self.logger.info("Kicking '{}' said '{}'".format(player.user.Username, data.Message))
            return player.sendErrorAndDisconnect(800)

        handleSendMessage(player, data)

    def handleSendAdoptPuffle(self, player, data):
        if self.isNaughty(data.Name):
            return player.sendError(441)
        handleSendAdoptPuffle(player, data)

    def ready(self):
        self.logger.info("SwearFilter is running!")
        self.logger.info("Loaded {} bad words!".format(len(self.words)))