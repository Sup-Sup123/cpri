from Houdini.HoudiniFactory import HoudiniFactory

server = HoudiniFactory(server="Login")
server.start()